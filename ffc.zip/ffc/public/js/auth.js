document.addEventListener('DOMContentLoaded', () => {
  // 检查用户是否已登录
  checkAuth();
  
  // 切换登录/注册表单
  const loginTab = document.getElementById('login-tab');
  const registerTab = document.getElementById('register-tab');
  const loginForm = document.getElementById('login-form');
  const registerForm = document.getElementById('register-form');
  
  loginTab.addEventListener('click', () => {
    loginTab.classList.add('active');
    registerTab.classList.remove('active');
    loginForm.classList.remove('hidden');
    registerForm.classList.add('hidden');
  });
  
  registerTab.addEventListener('click', () => {
    registerTab.classList.add('active');
    loginTab.classList.remove('active');
    registerForm.classList.remove('hidden');
    loginForm.classList.add('hidden');
  });
  
  // 登录表单提交
  const loginFormEl = document.getElementById('login');
  const loginError = document.getElementById('login-error');
  
  loginFormEl.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const username = document.getElementById('login-username').value.trim();
    const password = document.getElementById('login-password').value;
    
    if (!username || !password) {
      loginError.textContent = '请输入用户名和密码';
      return;
    }
    
    try {
      const response = await fetch('/api/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password })
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        loginError.textContent = data.error || '登录失败';
        return;
      }
      
      // 登录成功，跳转到聊天页面
      window.location.href = '/chat.html';
    } catch (error) {
      loginError.textContent = '服务器错误，请稍后再试';
      console.error('登录错误:', error);
    }
  });
  
  // 注册表单提交
  const registerFormEl = document.getElementById('register');
  const registerError = document.getElementById('register-error');
  
  registerFormEl.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const username = document.getElementById('register-username').value.trim();
    const password = document.getElementById('register-password').value;
    const confirmPassword = document.getElementById('register-confirm-password').value;
    
    if (!username || !password) {
      registerError.textContent = '请输入用户名和密码';
      return;
    }
    
    if (password !== confirmPassword) {
      registerError.textContent = '两次输入的密码不一致';
      return;
    }
    
    try {
      const response = await fetch('/api/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password })
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        registerError.textContent = data.error || '注册失败';
        return;
      }
      
      // 注册成功，切换到登录表单
      loginTab.click();
      loginError.textContent = '注册成功，请登录';
      document.getElementById('login-username').value = username;
    } catch (error) {
      registerError.textContent = '服务器错误，请稍后再试';
      console.error('注册错误:', error);
    }
  });
});

// 检查用户是否已登录
async function checkAuth() {
  try {
    const response = await fetch('/api/check-auth');
    const data = await response.json();
    
    if (data.authenticated) {
      // 已登录，跳转到聊天页面
      window.location.href = '/chat.html';
    }
  } catch (error) {
    console.error('检查认证状态错误:', error);
  }
}