document.addEventListener('DOMContentLoaded', () => {
  // 检查用户是否已登录
  checkAuth();
  
  // DOM元素
  const currentUserEl = document.getElementById('current-user');
  const logoutBtn = document.getElementById('logout-btn');
  const roomListEl = document.getElementById('room-list');
  const roomNameEl = document.getElementById('room-name');
  const onlineUsersEl = document.getElementById('online-users');
  const chatMessagesEl = document.getElementById('chat-messages');
  const messageInput = document.getElementById('message-input');
  const sendBtn = document.getElementById('send-btn');
  const emojiBtn = document.getElementById('emoji-btn');
  const emojiPicker = document.getElementById('emoji-picker');
  
  // 用户信息
  let currentUser = null;
  let currentRoom = null;
  let socket = null;
  
  // 表情列表
  const emojis = [
    '😀', '😁', '😂', '🤣', '😃', '😄', '😅', '😆', '😉', '😊', 
    '😋', '😎', '😍', '😘', '🥰', '😗', '😙', '😚', '🙂', '🤗',
    '🤩', '🤔', '🤨', '😐', '😑', '😶', '🙄', '😏', '😣', '😥',
    '😮', '🤐', '😯', '😪', '😫', '🥱', '😴', '😌', '😛', '😜',
    '😝', '🤤', '😒', '😓', '😔', '😕', '🙃', '🤑', '😲', '☹️',
    '🙁', '😖', '😞', '😟', '😤', '😢', '😭', '😦', '😧', '😨',
    '😩', '🤯', '😬', '😰', '😱', '🥵', '🥶', '😳', '🤪', '😵'
  ];
  
  // 初始化表情选择器
  initEmojiPicker();
  
  // 初始化事件监听器
  initEventListeners();
  
  // 检查用户是否已登录
  async function checkAuth() {
    try {
      const response = await fetch('/api/check-auth');
      const data = await response.json();
      
      if (!data.authenticated) {
        // 未登录，跳转到登录页面
        window.location.href = '/';
        return;
      }
      
      // 设置当前用户
      currentUser = {
        id: data.userId,
        username: data.username
      };
      
      currentUserEl.textContent = data.username;
      
      // 加载聊天室列表
      loadChatrooms();
      
      // 连接WebSocket
      connectWebSocket();
    } catch (error) {
      console.error('检查认证状态错误:', error);
      window.location.href = '/';
    }
  }
  
  // 加载聊天室列表
  async function loadChatrooms() {
    try {
      const response = await fetch('/api/chatrooms');
      const rooms = await response.json();
      
      roomListEl.innerHTML = '';
      
      rooms.forEach(room => {
        const roomItem = document.createElement('div');
        roomItem.className = 'room-item';
        roomItem.dataset.id = room.id;
        roomItem.innerHTML = `<h4>${room.name}</h4>`;
        
        roomItem.addEventListener('click', () => joinRoom(room.id, room.name));
        
        roomListEl.appendChild(roomItem);
      });
      
      // 默认加入第一个聊天室
      if (rooms.length > 0) {
        joinRoom(rooms[0].id, rooms[0].name);
      }
    } catch (error) {
      console.error('加载聊天室列表错误:', error);
    }
  }
  
  // 连接WebSocket
  function connectWebSocket() {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}`;
    
    socket = new WebSocket(wsUrl);
    
    socket.onopen = () => {
      console.log('WebSocket连接已建立');
      
      // 发送认证消息
      if (currentUser) {
        socket.send(JSON.stringify({
          type: 'auth',
          userId: currentUser.id,
          username: currentUser.username
        }));
      }
    };
    
    socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      switch (data.type) {
        case 'joinSuccess':
          // 成功加入聊天室
          updateOnlineUsers(data.users);
          break;
          
        case 'userJoined':
          // 新用户加入
          addSystemMessage(`${data.username} 加入了聊天室`);
          break;
          
        case 'userLeft':
          // 用户离开
          addSystemMessage(`${data.username} 离开了聊天室`);
          break;
          
        case 'newMessage':
          // 新消息
          addMessage(data);
          break;
          
        case 'error':
          // 错误消息
          console.error('WebSocket错误:', data.message);
          break;
      }
    };
    
    socket.onclose = () => {
      console.log('WebSocket连接已关闭');
      // 尝试重新连接
      setTimeout(connectWebSocket, 3000);
    };
    
    socket.onerror = (error) => {
      console.error('WebSocket错误:', error);
    };
  }
  
  // 加入聊天室
  function joinRoom(roomId, roomName) {
    if (!socket || socket.readyState !== WebSocket.OPEN) {
      console.error('WebSocket未连接');
      return;
    }
    
    // 更新UI
    currentRoom = roomId;
    roomNameEl.textContent = roomName;
    chatMessagesEl.innerHTML = '';
    
    // 更新活跃聊天室
    const roomItems = document.querySelectorAll('.room-item');
    roomItems.forEach(item => {
      if (item.dataset.id === roomId.toString()) {
        item.classList.add('active');
      } else {
        item.classList.remove('active');
      }
    });
    
    // 发送加入聊天室消息
    socket.send(JSON.stringify({
      type: 'join',
      roomId
    }));
    
    // 加载历史消息
    loadMessages(roomId);
  }
  
  // 加载历史消息
  async function loadMessages(roomId) {
    try {
      const response = await fetch(`/api/chatrooms/${roomId}/messages`);
      const messages = await response.json();
      
      chatMessagesEl.innerHTML = '';
      
      messages.forEach(message => {
        addMessage({
          messageId: message.id,
          userId: message.user_id,
          username: message.username,
          content: message.content,
          messageType: message.type,
          timestamp: message.created_at
        });
      });
      
      // 滚动到底部
      scrollToBottom();
    } catch (error) {
      console.error('加载消息错误:', error);
    }
  }
  
  // 发送消息
  function sendMessage() {
    const content = messageInput.value.trim();
    
    if (!content || !currentRoom || !socket || socket.readyState !== WebSocket.OPEN) {
      return;
    }
    
    socket.send(JSON.stringify({
      type: 'message',
      content,
      messageType: 'text',
      roomId: currentRoom
    }));
    
    // 清空输入框
    messageInput.value = '';
    messageInput.focus();
  }
  
  // 添加消息到聊天区域
  function addMessage(message) {
    const { userId, username, content, messageType, timestamp } = message;
    const isOwnMessage = currentUser && userId === currentUser.id;
    
    const messageEl = document.createElement('div');
    messageEl.className = `message ${isOwnMessage ? 'own' : ''}`;
    
    const time = new Date(timestamp).toLocaleTimeString();
    
    let messageContent = '';
    if (messageType === 'text') {
      messageContent = content;
    } else if (messageType === 'emoji') {
      messageContent = `<span class="emoji">${content}</span>`;
    }
    
    messageEl.innerHTML = `
      <div class="message-info">
        <span class="message-sender">${username}</span>
        <span class="message-time">${time}</span>
      </div>
      <div class="message-content">${messageContent}</div>
    `;
    
    chatMessagesEl.appendChild(messageEl);
    
    // 滚动到底部
    scrollToBottom();
  }
  
  // 添加系统消息
  function addSystemMessage(content) {
    const messageEl = document.createElement('div');
    messageEl.className = 'message system';
    
    const time = new Date().toLocaleTimeString();
    
    messageEl.innerHTML = `
      <div class="message-info">
        <span class="message-sender">系统</span>
        <span class="message-time">${time}</span>
      </div>
      <div class="message-content">${content}</div>
    `;
    
    chatMessagesEl.appendChild(messageEl);
    
    // 滚动到底部
    scrollToBottom();
  }
  
  // 更新在线用户
  function updateOnlineUsers(users) {
    onlineUsersEl.textContent = `在线用户: ${users.length}`;
  }
  
  // 滚动到底部
  function scrollToBottom() {
    chatMessagesEl.scrollTop = chatMessagesEl.scrollHeight;
  }
  
  // 初始化表情选择器
  function initEmojiPicker() {
    emojiPicker.innerHTML = '';
    
    emojis.forEach(emoji => {
      const emojiItem = document.createElement('div');
      emojiItem.className = 'emoji-item';
      emojiItem.textContent = emoji;
      
      emojiItem.addEventListener('click', () => {
        // 插入表情到输入框
        messageInput.value += emoji;
        messageInput.focus();
        
        // 隐藏表情选择器
        emojiPicker.classList.add('hidden');
      });
      
      emojiPicker.appendChild(emojiItem);
    });
  }
  
  // 初始化事件监听器
  function initEventListeners() {
    // 发送消息
    sendBtn.addEventListener('click', sendMessage);
    
    // 按Enter键发送消息
    messageInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        sendMessage();
      }
    });
    
    // 表情按钮
    emojiBtn.addEventListener('click', () => {
      emojiPicker.classList.toggle('hidden');
    });
    
    // 点击其他地方关闭表情选择器
    document.addEventListener('click', (e) => {
      if (!emojiPicker.contains(e.target) && e.target !== emojiBtn) {
        emojiPicker.classList.add('hidden');
      }
    });
    
    // 登出按钮
    logoutBtn.addEventListener('click', async () => {
      try {
        await fetch('/api/logout', { method: 'POST' });
        window.location.href = '/';
      } catch (error) {
        console.error('登出错误:', error);
      }
    });
  }
});