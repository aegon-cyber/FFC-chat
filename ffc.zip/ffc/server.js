const express = require('express');
const app = express();
const server = require('http').createServer(app);
const WebSocket = require('ws');
const sqlite3 = require('sqlite3').verbose();
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);

// 环境变量配置
const PORT = process.env.PORT || 3000;

// 中间件配置
app.use(express.json());
app.use(express.static('public'));
app.use(session({
    store: new SQLiteStore,
    secret: process.env.SESSION_SECRET || 'your_secret_key',
    resave: false,
    saveUninitialized: false
}));

// WebSocket 服务器
const wss = new WebSocket.Server({ server });

wss.on('connection', (ws) => {
    console.log('新客户端连接');

    ws.on('message', (message) => {
        // 广播消息给所有客户端
        wss.clients.forEach((client) => {
            if (client !== ws && client.readyState === WebSocket.OPEN) {
                client.send(message.toString());
            }
        });
    });
});

// 启动服务器
server.listen(PORT, () => {
    console.log(`服务器运行在端口 ${PORT}`);
});